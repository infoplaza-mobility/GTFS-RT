create function topoelementarray_append(topoelementarray, topoelement) returns topoelementarray
    immutable
    language sql
as
$$
	SELECT CASE
		WHEN $1 IS NULL THEN
			topology.TopoElementArray('{' || $2::text || '}')
		ELSE
			topology.TopoElementArray($1::int[][]||$2::int[])
		END;
$$;

alter function topoelementarray_append(topoelementarray, topoelement) owner to postgres;

