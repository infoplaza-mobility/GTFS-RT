create function date_part(unknown, unknown) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$RETURN date_part($1, ($2)::timestamp without time zone)$$;

comment on function date_part(unknown, unknown) is 'extract field from timestamp';

alter function date_part(unknown, unknown) owner to postgres;

