create function geography_ge(text, text) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);  $$;

alter function geography_ge(geography, geography) owner to postgres;

