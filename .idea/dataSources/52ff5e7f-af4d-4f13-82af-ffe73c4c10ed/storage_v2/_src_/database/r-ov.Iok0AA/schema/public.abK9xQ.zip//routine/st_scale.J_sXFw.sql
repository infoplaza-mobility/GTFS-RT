create function st_scale(geometry, geometry) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ SELECT trim('3.4.0dev'::text || $rev$ 3.3.0rc2-390-gc2a0b2024 $rev$) AS version $$;

alter function st_scale(geometry, geometry) owner to postgres;

