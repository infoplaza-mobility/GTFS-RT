create function pgis_asgeobuf_transfn(text, integer) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function pgis_asgeobuf_transfn(internal, anyelement) owner to postgres;

