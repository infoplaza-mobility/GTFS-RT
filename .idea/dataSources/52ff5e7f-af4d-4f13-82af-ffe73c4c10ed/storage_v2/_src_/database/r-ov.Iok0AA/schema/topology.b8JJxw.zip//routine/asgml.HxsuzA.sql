create function asgml(tg topogeometry) returns text
    stable
    language sql
as
$$
 SELECT topology.AsGML($1, 'gml');
$$;

comment on function asgml(topogeometry) is 'args: tg - Returns the GML representation of a topogeometry.';

alter function asgml(topogeometry) owner to postgres;

