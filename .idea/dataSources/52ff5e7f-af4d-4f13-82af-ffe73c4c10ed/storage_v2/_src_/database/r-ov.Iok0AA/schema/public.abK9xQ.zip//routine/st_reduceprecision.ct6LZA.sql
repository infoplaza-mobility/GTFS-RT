create function st_reduceprecision(geom1 geometry, geom2 geometry) returns boolean
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$SELECT public._ST_Contains($2,$1)$$;

alter function st_reduceprecision(geometry, double precision) owner to postgres;

