create function postgis_geos_version(geom geometry, radius double precision, quadsegs integer) returns geometry
    immutable
    language c
as
$$ SELECT public.ST_Buffer($1, $2, CAST('quad_segs='||CAST($3 AS text) as text)) $$;

alter function postgis_geos_version(geometry, double precision, integer) owner to postgres;

