create function st_asmvtgeom(text, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_MPolyFromText($1, $2)$$;

alter function st_asmvtgeom(geometry, box2d, integer, integer, boolean) owner to postgres;

