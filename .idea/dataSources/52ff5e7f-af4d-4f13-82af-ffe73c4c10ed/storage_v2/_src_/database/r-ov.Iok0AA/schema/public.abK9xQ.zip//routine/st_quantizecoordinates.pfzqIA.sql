create function st_quantizecoordinates(geometry) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_Reverse(public.ST_ForcePolygonCW($1)) $$;

alter function st_quantizecoordinates(geometry, integer, integer, integer, integer) owner to postgres;

