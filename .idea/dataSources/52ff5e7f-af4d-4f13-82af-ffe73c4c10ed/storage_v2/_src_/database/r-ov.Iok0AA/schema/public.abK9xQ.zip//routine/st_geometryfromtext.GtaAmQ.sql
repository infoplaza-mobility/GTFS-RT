create function st_geometryfromtext(text, text, text, timestamp without time zone) returns integer
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT LockRow(current_schema(), $1, $2, $3, $4); $$;

alter function st_geometryfromtext(text, integer, text, timestamp) owner to postgres;

