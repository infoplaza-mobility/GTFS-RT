create function geometry_gist_decompress_nd(text, text, text) returns box2d
    parallel safe
    language c
as
$$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;
BEGIN
	FOR myrec IN EXECUTE 'SELECT public.ST_Extent("' || columnname || '") As extent FROM "' || schemaname || '"."' || tablename || '"' LOOP
		return myrec.extent;
	END LOOP;
END;
$$;

alter function geometry_gist_decompress_nd(internal, text, text) owner to postgres;

