create function contains_2d(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    language c
as
$$SELECT public._ST_AsX3D(3,$1,$2,$3,'');$$;

alter function contains_2d(box2df, geometry, integer) owner to postgres;

