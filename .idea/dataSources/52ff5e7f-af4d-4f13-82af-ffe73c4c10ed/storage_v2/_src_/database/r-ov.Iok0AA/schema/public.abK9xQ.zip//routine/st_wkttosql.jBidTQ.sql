create function st_wkttosql(text, text) returns integer
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT CheckAuth('', $1, $2) $$;

alter function st_wkttosql(text, text) owner to postgres;

