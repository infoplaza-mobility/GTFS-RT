create function log(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN log((10)::numeric, $1);

comment on function log(unknown) is 'base 10 logarithm';

alter function log(unknown) owner to postgres;

