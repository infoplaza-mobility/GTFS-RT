create function st_makepolygon(schema_name character varying, table_name character varying) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ SELECT public.DropGeometryTable('',$1,$2) $$;

alter function st_makepolygon(geometry, geometry[]) owner to postgres;

