create function quote_nullable(unknown) returns text
    immutable
    parallel safe
    cost 1
    language internal
as
$$select pg_catalog.quote_nullable($1::pg_catalog.text)$$;

comment on function quote_nullable(unknown) is 'quote a possibly-null literal for usage in a querystring';

alter function quote_nullable(unknown) owner to postgres;

