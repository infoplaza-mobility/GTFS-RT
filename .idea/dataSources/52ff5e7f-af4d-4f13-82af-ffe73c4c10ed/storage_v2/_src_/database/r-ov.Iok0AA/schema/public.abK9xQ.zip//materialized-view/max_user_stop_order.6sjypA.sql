create materialized view max_user_stop_order as
SELECT planned_passtimes."DataOwnerCode",
       planned_passtimes."LinePlanningNumber",
       planned_passtimes."LocalServiceLevelCode",
       planned_passtimes."JourneyNumber",
       max(planned_passtimes."UserStopOrderNumber") AS maxuserstopordernumber
FROM "PassTimes".planned_passtimes
GROUP BY planned_passtimes."DataOwnerCode", planned_passtimes."LinePlanningNumber",
         planned_passtimes."LocalServiceLevelCode", planned_passtimes."JourneyNumber";

alter materialized view max_user_stop_order owner to postgres;

create index idx_max_user_stop_order
    on max_user_stop_order ("DataOwnerCode", "LinePlanningNumber", "LocalServiceLevelCode", "JourneyNumber");

