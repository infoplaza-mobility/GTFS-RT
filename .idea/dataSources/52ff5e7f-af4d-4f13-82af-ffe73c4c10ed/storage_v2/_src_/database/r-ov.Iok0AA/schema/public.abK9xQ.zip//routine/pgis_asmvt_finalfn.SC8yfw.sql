create function pgis_asmvt_finalfn(text, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$
	SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function pgis_asmvt_finalfn(internal, integer) owner to postgres;

