create function quote_literal(unknown) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$select pg_catalog.quote_literal($1::pg_catalog.text)$$;

comment on function quote_literal(unknown) is 'quote a literal for usage in a querystring';

alter function quote_literal(unknown) owner to postgres;

