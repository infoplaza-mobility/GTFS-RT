create function postgis_topology_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.4.0dev'::text || $rev$ 3.3.0rc2-390-gc2a0b2024 $rev$) AS version $$;

alter function postgis_topology_scripts_installed() owner to postgres;

