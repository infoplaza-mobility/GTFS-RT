create function st_coveredby(geometry, box2df) returns boolean
    immutable
    parallel safe
    language sql
as
$$SELECT $2 OPERATOR(public.~) $1;$$;

alter function st_coveredby(text, text) owner to postgres;

