create function st_startpoint(geom1 geometry, geom2 geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$SELECT public._ST_LongestLine(public.ST_ConvexHull($1), public.ST_ConvexHull($2))$$;

alter function st_startpoint(geometry, geometry) owner to postgres;

