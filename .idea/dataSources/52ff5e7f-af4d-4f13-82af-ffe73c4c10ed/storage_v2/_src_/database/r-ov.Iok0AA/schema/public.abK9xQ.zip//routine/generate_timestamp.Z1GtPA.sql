create function generate_timestamp(operationdate character varying, targetarrivaltime text) returns timestamp with time zone
    language plpgsql
as
$$
        DECLARE
            hour_part   integer;
            minute_part integer;
            second_part integer;
            target_time interval;
        BEGIN
        
            -- If the time is 0 or 00:00:00, return null
            IF (TargetArrivalTime IN ('0', '00:00:00')) THEN
                RETURN NULL;
            END IF;
        
            hour_part := split_part(TargetArrivalTime, ':', 1)::int;
            minute_part := split_part(TargetArrivalTime, ':', 2)::int;
            second_part := split_part(TargetArrivalTime, ':', 3)::int;
        
            RETURN (SELECT CASE
                               -- Check if the time is greater than 24 hours (e.g., 25:43:32)
                               WHEN hour_part >= 24 THEN
        
                                   -- Extract hours, minutes, and seconds from the time string
                                       (to_timestamp(
                                                                        OperationDate || ' ' || hour_part - 24 || ':' ||
                                                                        minute_part || ':' || second_part,
                                                                        'YYYY-MM-DD HH24:MI:SS') + interval '1 day'
                                           ) AT TIME ZONE 'UTC' AT TIME ZONE 'Europe/Amsterdam'
                               ELSE
                                   -- If the time is within 24 hours, use the original time
                                       (to_timestamp(OperationDate || ' ' || TargetArrivalTime,
                                                     'YYYY-MM-DD HH24:MI:SS')) AT TIME ZONE 'UTC' AT TIME ZONE
                                       'Europe/Amsterdam'
                               END);
        END;
        $$;

alter function generate_timestamp(varchar, text) owner to postgres;

