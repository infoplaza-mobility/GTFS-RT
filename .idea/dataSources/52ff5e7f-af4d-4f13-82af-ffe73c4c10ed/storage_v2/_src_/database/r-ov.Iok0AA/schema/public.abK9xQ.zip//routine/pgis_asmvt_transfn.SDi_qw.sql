create function pgis_asmvt_transfn(text, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_PolyFromText($1, $2)$$;

alter function pgis_asmvt_transfn(internal, anyelement, text, integer, text) owner to postgres;

