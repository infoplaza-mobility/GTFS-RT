create function age(timestamp with time zone) returns interval
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$RETURN age((CURRENT_DATE)::timestamp without time zone, $1)$$;

comment on function age(unknown) is 'age of a transaction ID, in transactions before current transaction';

alter function age(unknown) owner to postgres;

