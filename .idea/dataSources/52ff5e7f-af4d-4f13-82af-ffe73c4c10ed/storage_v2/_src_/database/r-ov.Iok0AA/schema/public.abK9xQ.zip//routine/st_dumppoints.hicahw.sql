create function st_dumppoints(geometry) returns text
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$
	SELECT CASE WHEN pg_catalog.split_part(s,'.',1)::integer > 9 THEN pg_catalog.split_part(s,'.',1) || '0'
	ELSE pg_catalog.split_part(s,'.', 1) || pg_catalog.split_part(s,'.', 2) END AS v
	FROM pg_catalog.substring(version(), 'PostgreSQL ([0-9\.]+)') AS s;
$$;

alter function st_dumppoints(geometry) owner to postgres;

