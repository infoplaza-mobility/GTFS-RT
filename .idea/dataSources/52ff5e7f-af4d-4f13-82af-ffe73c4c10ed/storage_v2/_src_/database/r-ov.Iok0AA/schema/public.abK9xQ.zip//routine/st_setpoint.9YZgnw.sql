create function st_setpoint(schema_name character varying, table_name character varying, column_name character varying) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('',$1,$2,$3) into ret;
	RETURN ret;
END;
$$;

alter function st_setpoint(geometry, integer, geometry) owner to postgres;

