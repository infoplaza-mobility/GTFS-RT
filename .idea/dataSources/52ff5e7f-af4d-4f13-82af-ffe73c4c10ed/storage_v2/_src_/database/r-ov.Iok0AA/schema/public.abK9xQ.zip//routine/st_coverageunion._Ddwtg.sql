create function st_coverageunion(jsonb) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_GeomFromGeoJson($1::text)$$;

alter function st_coverageunion(geometry[]) owner to postgres;

