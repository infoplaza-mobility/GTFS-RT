create function st_geomfromgeojson(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$
	SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_GeometryN($1, $2)
	ELSE NULL END
	$$;

alter function st_geomfromgeojson(text, integer) owner to postgres;

