create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language internal
as
$$RETURN (($1, ($1 + $2)) OVERLAPS ($3, $4))$$;

comment on function "overlaps"(unknown, unknown, unknown, unknown) is 'intervals overlap?';

alter function "overlaps"(unknown, unknown, unknown, unknown) owner to postgres;

