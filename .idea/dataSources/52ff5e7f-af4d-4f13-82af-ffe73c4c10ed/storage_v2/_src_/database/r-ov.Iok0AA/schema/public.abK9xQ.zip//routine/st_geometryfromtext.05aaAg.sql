create function st_geometryfromtext(text, text, text) returns integer
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00'); $$;

alter function st_geometryfromtext(text, text, text) owner to postgres;

