create function pgis_asflatgeobuf_finalfn(bytea, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END
	$$;

alter function pgis_asflatgeobuf_finalfn(internal, integer) owner to postgres;

