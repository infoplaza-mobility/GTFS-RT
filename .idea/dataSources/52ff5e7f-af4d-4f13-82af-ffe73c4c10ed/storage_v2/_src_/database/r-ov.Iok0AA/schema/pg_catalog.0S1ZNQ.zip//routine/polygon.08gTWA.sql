create function polygon(unknown) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$RETURN polygon(12, $1)$$;

comment on function polygon(unknown) is 'convert path to polygon';

alter function polygon(unknown) owner to postgres;

