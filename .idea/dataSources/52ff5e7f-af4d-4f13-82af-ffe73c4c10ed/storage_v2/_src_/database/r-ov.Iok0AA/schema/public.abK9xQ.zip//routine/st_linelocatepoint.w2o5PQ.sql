create function st_linelocatepoint(geometry, gidx) returns boolean
    immutable
    strict
    parallel safe
    language c
as
$$SELECT $2 OPERATOR(public.&&&) $1;$$;

alter function st_linelocatepoint(geography, geography, boolean) owner to postgres;

