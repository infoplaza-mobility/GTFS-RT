create function f_concat_space(t1 text, t2 text) returns text
    immutable
    parallel safe
    language sql
as
$$
    SELECT CASE
            WHEN t1 IS NULL THEN t2
            WHEN t2 IS NULL THEN t1
            ELSE t1 || ' ' || t2
          END
    $$;

alter function f_concat_space(text, text) owner to postgres;

