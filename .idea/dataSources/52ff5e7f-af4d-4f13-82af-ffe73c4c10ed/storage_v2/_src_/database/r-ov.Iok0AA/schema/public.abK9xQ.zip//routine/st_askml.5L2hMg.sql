create function st_askml(text, text) returns boolean
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_CoveredBy($1::public.geometry, $2::public.geometry);  $$;

alter function st_askml(geography, integer, text) owner to postgres;

