create function st_makeenvelope(table_name character varying, column_name character varying) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;

alter function st_makeenvelope(double precision, double precision, double precision, double precision, integer) owner to postgres;

