create function is_contained_2d(geometry, box2df) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT ST_Angle(St_StartPoint($1), ST_EndPoint($1), St_StartPoint($2), ST_EndPoint($2))$$;

alter function is_contained_2d(geometry, box2df) owner to postgres;

