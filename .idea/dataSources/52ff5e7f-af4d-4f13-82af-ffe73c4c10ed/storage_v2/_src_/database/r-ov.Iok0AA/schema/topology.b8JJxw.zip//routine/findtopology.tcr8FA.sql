create function findtopology(integer) returns topology
    language sql
as
$$
    SELECT *
    FROM topology.topology
    WHERE id = $1
$$;

comment on function findtopology(integer) is 'args: id - Returns a topology record by different means.';

alter function findtopology(integer) owner to postgres;

