create function pgis_asflatgeobuf_transfn(bytea) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function pgis_asflatgeobuf_transfn(internal, anyelement, boolean, text) owner to postgres;

