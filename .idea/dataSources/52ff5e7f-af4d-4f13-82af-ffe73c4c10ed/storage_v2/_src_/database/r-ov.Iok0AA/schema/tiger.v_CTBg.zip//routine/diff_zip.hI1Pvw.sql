create function diff_zip(zip1 character varying, zip2 character varying) returns integer
    immutable
    strict
    parallel safe
    cost 200
    language sql
as
$$ SELECT abs(to_number( CASE WHEN trim(substring($1,1,5)) ~ '^[0-9]+$' THEN $1 ELSE '0' END,'99999')::integer - to_number( CASE WHEN trim(substring($2,1,5)) ~ '^[0-9]+$' THEN $2 ELSE '0' END,'99999')::integer )::integer;  $$;

alter function diff_zip(varchar, varchar) owner to postgres;

