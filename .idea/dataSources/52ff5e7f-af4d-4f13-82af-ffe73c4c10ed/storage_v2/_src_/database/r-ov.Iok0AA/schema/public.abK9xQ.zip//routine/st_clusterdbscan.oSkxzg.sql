create function st_clusterdbscan(integer) returns text
    immutable
    window
    strict
    parallel safe
    cost 5000
    language c
as
$$
	BEGIN
	RETURN proj4text::text FROM public.spatial_ref_sys WHERE srid= $1;
	END;
	$$;

alter function st_clusterdbscan(geometry, double precision, integer) owner to postgres;

