create function box3d(geometry, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$SELECT (public.ST_isValidDetail($1, $2)).valid$$;

alter function box3d(box2d, integer) owner to postgres;

