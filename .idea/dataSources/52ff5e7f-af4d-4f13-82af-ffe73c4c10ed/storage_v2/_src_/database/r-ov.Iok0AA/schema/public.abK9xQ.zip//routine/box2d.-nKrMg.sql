create function box2d(geometry, integer) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE WHEN valid THEN 'Valid Geometry' ELSE reason END FROM (
		SELECT (public.ST_isValidDetail($1, $2)).*
	) foo
	$$;

alter function box2d(box3d, integer) owner to postgres;

