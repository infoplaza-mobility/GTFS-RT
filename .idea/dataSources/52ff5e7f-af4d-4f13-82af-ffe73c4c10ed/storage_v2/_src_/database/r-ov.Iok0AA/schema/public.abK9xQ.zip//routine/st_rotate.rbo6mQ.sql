create function st_rotate(geom geometry, pipeline text, to_srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.postgis_transform_pipeline_geometry($1, $2, TRUE, $3)$$;

alter function st_rotate(geometry, double precision, geometry) owner to postgres;

