create function st_shiftlongitude(geom geometry, zvalue double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$SELECT public.ST_Force3DZ($1, $2)$$;

alter function st_shiftlongitude(geometry, double precision) owner to postgres;

