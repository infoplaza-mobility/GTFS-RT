create function pgis_asmvt_combinefn(text) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function pgis_asmvt_combinefn(internal, internal) owner to postgres;

