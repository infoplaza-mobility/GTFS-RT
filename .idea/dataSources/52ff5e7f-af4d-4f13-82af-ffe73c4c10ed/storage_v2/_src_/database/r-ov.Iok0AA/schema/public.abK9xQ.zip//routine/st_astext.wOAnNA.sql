create function st_astext(text, text, text, text) returns integer
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00'); $$;

alter function st_astext(geometry, integer, text, text) owner to postgres;

