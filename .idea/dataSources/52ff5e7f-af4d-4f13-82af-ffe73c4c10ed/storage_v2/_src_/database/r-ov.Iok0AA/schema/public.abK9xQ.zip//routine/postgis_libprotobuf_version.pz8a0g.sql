create function postgis_libprotobuf_version(text) returns geometry
    immutable
    strict
    language c
as
$$SELECT public.ST_MPolyFromText($1)$$;

alter function postgis_libprotobuf_version(text) owner to postgres;

