create function st_dwithin(geometry, box2df) returns boolean
    immutable
    parallel safe
    language sql
as
$$SELECT $2 OPERATOR(public.&&) $1;$$;

alter function st_dwithin(text, text, double precision) owner to postgres;

