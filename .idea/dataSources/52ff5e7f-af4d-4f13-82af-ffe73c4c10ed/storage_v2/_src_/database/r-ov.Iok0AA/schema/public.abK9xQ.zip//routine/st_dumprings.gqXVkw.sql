create function st_dumprings(geometry) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$SELECT '140'::text AS version$$;

alter function st_dumprings(geometry) owner to postgres;

