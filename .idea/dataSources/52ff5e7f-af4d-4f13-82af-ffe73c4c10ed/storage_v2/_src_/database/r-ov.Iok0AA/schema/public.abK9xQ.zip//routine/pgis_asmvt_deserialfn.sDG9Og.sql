create function pgis_asmvt_deserialfn(text, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_MLineFromText($1, $2)$$;

alter function pgis_asmvt_deserialfn(bytea, internal) owner to postgres;

