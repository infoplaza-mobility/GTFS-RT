create function pgis_asgeobuf_transfn(text) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function pgis_asgeobuf_transfn(internal, anyelement, text) owner to postgres;

