create function st_numinteriorrings(bytea) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_numinteriorrings(geometry) owner to postgres;

