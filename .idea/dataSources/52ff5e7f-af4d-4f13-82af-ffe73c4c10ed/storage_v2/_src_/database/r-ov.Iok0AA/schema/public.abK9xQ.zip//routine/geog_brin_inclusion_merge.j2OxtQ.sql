create function geog_brin_inclusion_merge(text) returns double precision
    parallel safe
    language c
as
$$ SELECT public.ST_Length($1::public.geometry);  $$;

alter function geog_brin_inclusion_merge(internal, internal) owner to postgres;

