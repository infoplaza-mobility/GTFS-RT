create function st_asmarc21(geometry) returns integer
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$
	SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_NumGeometries($1)
	ELSE NULL END
	$$;

alter function st_asmarc21(geometry, text) owner to postgres;

