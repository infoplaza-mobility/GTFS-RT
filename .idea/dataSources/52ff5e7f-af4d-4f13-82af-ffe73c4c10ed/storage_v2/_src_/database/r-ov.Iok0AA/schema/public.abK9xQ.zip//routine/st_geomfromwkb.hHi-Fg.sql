create function st_geomfromwkb(text) returns text
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT public.ST_AsText($1::public.geometry);  $$;

alter function st_geomfromwkb(bytea, integer) owner to postgres;

