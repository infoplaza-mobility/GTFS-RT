create function st_astwkb(geometry, double precision, double precision, double precision, double precision) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$SELECT public.ST_Affine($1,  $4, 0, 0,  0, $5, 0,
		0, 0, 1,  $2 * $4, $3 * $5, 0)$$;

alter function st_astwkb(geometry, integer, integer, integer, boolean, boolean) owner to postgres;

