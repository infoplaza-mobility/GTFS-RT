create function st_pointfromgeohash(bytea) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_pointfromgeohash(text, integer) owner to postgres;

