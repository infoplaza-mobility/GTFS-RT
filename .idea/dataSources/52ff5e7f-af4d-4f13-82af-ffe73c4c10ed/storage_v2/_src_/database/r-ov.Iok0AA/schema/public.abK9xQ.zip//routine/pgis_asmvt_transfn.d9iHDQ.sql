create function pgis_asmvt_transfn(text) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_PolyFromText($1)$$;

alter function pgis_asmvt_transfn(internal, anyelement, text, integer, text, text) owner to postgres;

