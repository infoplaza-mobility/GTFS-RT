create function timestamptz(unknown, unknown) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$RETURN (($1 + $2))::timestamp with time zone$$;

comment on function timestamptz(unknown, unknown) is 'adjust timestamptz precision';

alter function timestamptz(unknown, unknown) owner to postgres;

