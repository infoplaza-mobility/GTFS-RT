create function pgis_asmvt_serialfn(text) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_MLineFromText($1)$$;

alter function pgis_asmvt_serialfn(internal) owner to postgres;

