create function st_union(text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$SELECT public._ST_GeomFromGML($1, 0)$$;

alter function st_union(geometry[]) owner to postgres;

