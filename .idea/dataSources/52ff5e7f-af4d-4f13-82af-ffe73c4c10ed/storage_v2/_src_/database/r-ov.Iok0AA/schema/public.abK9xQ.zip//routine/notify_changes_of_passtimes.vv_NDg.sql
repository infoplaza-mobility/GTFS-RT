create function notify_changes_of_passtimes() returns trigger
    language plpgsql
as
$$
    BEGIN
      PERFORM pg_notify(
        concat('passtimes_update_listener_', tg_argv[0], '_', tg_argv[1]),
        json_build_object(
          'operation', TG_OP,
          'record', JSONB_BUILD_OBJECT(
              'LinePlanningNumber',
              NEW."LinePlanningNumber",
              'JourneyNumber',
              NEW."JourneyNumber",
              'UserStopCode',
              NEW."UserStopCode",
              'ExpectedArrivalTime',
              NEW."ExpectedArrivalTime",
              'ExpectedDepartureTime',
              NEW."ExpectedDepartureTime",
              'TripStopStatus',
              NEW."TripStopStatus",
              'RecordedArrivalTime',
              NEW."RecordedArrivalTime",
              'RecordedDepartureTime',
              NEW."RecordedDepartureTime",
              'LastUpdateTimeStamp',
              NEW."LastUpdateTimeStamp"
              )
        )::text
      );

      RETURN NEW;
    END;
    $$;

alter function notify_changes_of_passtimes() owner to postgres;

