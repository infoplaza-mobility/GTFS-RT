create function st_rotatez(geom geometry, pipeline text, to_srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.postgis_transform_pipeline_geometry($1, $2, FALSE, $3)$$;

alter function st_rotatez(geometry, double precision, integer) owner to postgres;

