create function st_transform(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$SELECT public.ST_SnapToGrid($1, 0, 0, $2, $3)$$;

alter function st_transform(geometry, integer, double precision) owner to postgres;

