create function st_polygonize(character varying, character varying, character varying, integer) returns text
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$
DECLARE
	ret  text;
BEGIN
	SELECT public.UpdateGeometrySRID('',$1,$2,$3,$4) into ret;
	RETURN ret;
END;
$$;

alter function st_polygonize(geometry[], varchar, varchar, integer) owner to postgres;

