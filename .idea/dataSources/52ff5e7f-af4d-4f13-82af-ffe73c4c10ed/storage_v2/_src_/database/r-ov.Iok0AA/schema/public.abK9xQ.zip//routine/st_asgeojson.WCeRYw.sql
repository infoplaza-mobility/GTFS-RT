create function st_asgeojson(text, text) returns boolean
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_Intersects($1::public.geometry, $2::public.geometry);  $$;

alter function st_asgeojson(geography, integer, integer) owner to postgres;

