create function geometrytype(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$
	SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)
	$$;

alter function geometrytype(geography, integer) owner to postgres;

