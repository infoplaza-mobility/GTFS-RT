create function st_rotate(geom geometry, from_proj text, to_srid integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.postgis_transform_geometry($1, $2, proj4text, $3)
	FROM spatial_ref_sys WHERE srid=$3;$$;

alter function st_rotate(geometry, double precision, integer) owner to postgres;

