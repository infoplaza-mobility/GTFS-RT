create function st_snaptogrid(g1 geometry, tolerance double precision DEFAULT 0.0, extend_to geometry DEFAULT NULL::geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT public._ST_Voronoi(g1, extend_to, tolerance, true) $$;

alter function st_snaptogrid(geometry, double precision, double precision) owner to postgres;

