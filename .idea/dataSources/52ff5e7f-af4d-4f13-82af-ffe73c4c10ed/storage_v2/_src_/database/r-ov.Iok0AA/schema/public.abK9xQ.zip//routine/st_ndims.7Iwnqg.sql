create function st_ndims(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$SELECT public.ST_Translate($1, $2, $3, 0)$$;

alter function st_ndims(geometry, double precision, double precision) owner to postgres;

