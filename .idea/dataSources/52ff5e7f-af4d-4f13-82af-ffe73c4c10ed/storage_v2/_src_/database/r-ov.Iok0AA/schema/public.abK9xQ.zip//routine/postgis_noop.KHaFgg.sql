create function postgis_noop(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$SELECT public.ST_Rotate($1, $2)$$;

alter function postgis_noop(geometry, double precision) owner to postgres;

