create function findlayer(schema_name name, table_name name, feature_column name) returns layer
    language sql
as
$$
    SELECT * FROM topology.layer
    WHERE schema_name = $1
    AND table_name = $2
    AND feature_column = $3;
$$;

comment on function findlayer(name, name, name) is 'args: schema_name, table_name, feature_column - Returns a topology.layer record by different means.';

alter function findlayer(name, name, name) owner to postgres;

