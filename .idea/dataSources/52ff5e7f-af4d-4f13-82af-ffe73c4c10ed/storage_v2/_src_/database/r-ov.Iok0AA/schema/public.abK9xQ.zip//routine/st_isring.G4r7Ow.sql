create function st_isring(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT CAST(public.ST_Box2dFromGeoHash($1, $2) AS geometry); $$;

alter function st_isring(geometry, integer) owner to postgres;

