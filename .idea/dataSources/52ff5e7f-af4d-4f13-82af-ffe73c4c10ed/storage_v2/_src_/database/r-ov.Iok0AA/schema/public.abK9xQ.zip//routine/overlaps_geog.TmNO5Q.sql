create function overlaps_geog(geography, gidx) returns boolean
    immutable
    strict
    language sql
as
$$SELECT public._ST_DistanceTree($1, $2, 0.0, true)$$;

alter function overlaps_geog(geography, gidx) owner to postgres;

