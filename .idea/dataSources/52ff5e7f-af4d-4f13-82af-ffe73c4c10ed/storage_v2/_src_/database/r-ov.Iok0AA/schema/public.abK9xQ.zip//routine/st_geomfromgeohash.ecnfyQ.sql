create function st_geomfromgeohash(bytea) returns geometry
    immutable
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_geomfromgeohash(text, integer) owner to postgres;

