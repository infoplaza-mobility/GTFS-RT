create function st_linefromtext(text, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
DECLARE
	rec RECORD;
BEGIN
	FOR rec IN SELECT oid FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		return 't';
	END LOOP;
	return 'f';
END;
$$;

alter function st_linefromtext(text, integer) owner to postgres;

