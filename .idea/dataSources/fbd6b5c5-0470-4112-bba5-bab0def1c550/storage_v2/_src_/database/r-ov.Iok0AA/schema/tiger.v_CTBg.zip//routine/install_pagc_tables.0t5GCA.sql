create function install_pagc_tables() returns void
    language plpgsql
as
$$
DECLARE var_temp text;
BEGIN
	var_temp := tiger.SetSearchPathForInstall('tiger'); /** set set search path to have tiger in front **/
	IF NOT EXISTS(SELECT table_name FROM information_schema.columns WHERE table_schema = 'tiger' AND table_name = 'pagc_gaz')  THEN
		CREATE TABLE pagc_gaz (id serial NOT NULL primary key ,seq integer ,word text, stdword text, token integer,is_custom boolean NOT NULL default true);
		GRANT SELECT ON pagc_gaz TO public;
	END IF;
	IF NOT EXISTS(SELECT table_name FROM information_schema.columns WHERE table_schema = 'tiger' AND table_name = 'pagc_lex')  THEN
		CREATE TABLE pagc_lex (id serial NOT NULL primary key,seq integer,word text,stdword text,token integer,is_custom boolean NOT NULL default true);
		GRANT SELECT ON pagc_lex TO public;
	END IF;
	IF NOT EXISTS(SELECT table_name FROM information_schema.columns WHERE table_schema = 'tiger' AND table_name = 'pagc_rules')  THEN
		CREATE TABLE pagc_rules (id serial NOT NULL primary key,rule text, is_custom boolean DEFAULT true);
		GRANT SELECT ON pagc_rules TO public;
	END IF;
	IF NOT EXISTS(SELECT table_name FROM information_schema.columns WHERE table_schema = 'tiger' AND table_name = 'pagc_gaz' AND data_type='text')  THEN
	-- its probably old table structure change type of lex and gaz columns
		ALTER TABLE tiger.pagc_lex ALTER COLUMN word TYPE text;
		ALTER TABLE tiger.pagc_lex ALTER COLUMN stdword TYPE text;
		ALTER TABLE tiger.pagc_gaz ALTER COLUMN word TYPE text;
		ALTER TABLE tiger.pagc_gaz ALTER COLUMN stdword TYPE text;
	END IF;
	IF NOT EXISTS(SELECT table_name FROM information_schema.columns WHERE table_schema = 'tiger' AND table_name = 'pagc_rules' AND column_name = 'is_custom' )  THEN
	-- its probably old table structure add column
		ALTER TABLE tiger.pagc_rules ADD COLUMN is_custom boolean NOT NULL DEFAULT false;
	END IF;
END;
$$;

alter function install_pagc_tables() owner to postgres;

