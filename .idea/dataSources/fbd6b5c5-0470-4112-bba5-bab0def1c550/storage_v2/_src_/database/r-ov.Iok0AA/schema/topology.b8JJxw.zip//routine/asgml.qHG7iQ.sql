create function asgml(tg topogeometry, visitedtable regclass, nsprefix text) returns text
    language sql
as
$$
 SELECT topology.AsGML($1, $3, 15, 1, $2);
$$;

comment on function asgml(topogeometry, regclass, text) is 'args: tg, visitedTable, nsprefix - Returns the GML representation of a topogeometry.';

alter function asgml(topogeometry, regclass, text) owner to postgres;

