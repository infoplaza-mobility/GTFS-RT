create function createtopology(character varying) returns integer
    strict
    language sql
as
$$ SELECT topology.CreateTopology($1, ST_SRID('POINT EMPTY'::geometry), 0); $$;

comment on function createtopology(varchar) is 'args: topology_schema_name - Creates a new topology schema and registers this new schema in the topology.topology table.';

alter function createtopology(varchar) owner to postgres;

