create function createtopology(toponame character varying, srid integer, prec double precision) returns integer
    strict
    language sql
as
$$ SELECT topology.CreateTopology($1, $2, $3, false);$$;

comment on function createtopology(varchar, integer, double precision) is 'args: topology_schema_name, srid, prec - Creates a new topology schema and registers this new schema in the topology.topology table.';

alter function createtopology(varchar, integer, double precision) owner to postgres;

