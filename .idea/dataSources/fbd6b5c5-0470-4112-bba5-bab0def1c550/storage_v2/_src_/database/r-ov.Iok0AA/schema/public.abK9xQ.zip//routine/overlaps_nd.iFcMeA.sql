create function overlaps_nd(geometry, gidx) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(public.&&&) $1;$$;

alter function overlaps_nd(geometry, gidx) owner to postgres;

